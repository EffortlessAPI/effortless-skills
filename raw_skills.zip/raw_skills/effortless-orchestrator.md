---
name: effortless-orchestrator
description: >
  Top-level entry point for Effortless Rulebook (ERB) projects — any project with
  effortless.json or an effortless-rulebook/ directory, or any request to set up /
  install / update Effortless tooling. Holds the mental model, axioms, guardrails, token
  discipline, the load-gate policy for every effortless-* skill, and the routing table.
  Load this first.
audience: customer
---

# Effortless Rulebook (ERB) — Orchestrator

> **Load-bearing axiom #1: `effortless-rulebook.json` IS the single source of truth.**
> The rulebook JSON file is the hub. Everything else — Airtable, Postgres, generated SQL,
> Go, Python, OWL, XLSX, LLM-direct edits — are **spokes**. Some spokes are *input*
> surfaces (Airtable, LLM edits, hand-edits with permission). Most spokes are *output*
> substrates regenerated mechanically from the rulebook. The combination that matters
> most today is **LLM + ERB + Postgres** — an LLM-tendable JSON hub generating an
> ACID-compliant substrate. Airtable is one optional editing surface, no longer
> privileged. Never edit a generated spoke — edit the rulebook (directly or via an
> input spoke) and rebuild.

> **Load-bearing axiom #2: CMCC holds — operate from inside the conjecture.**
> Any sufficiently crisp conceptual world decomposes into a DAG of first-class
> semantic units (**S/D/L/A/F**: Schema, Data, Lookups, Aggregations, Functions)
> such that each inference remains locally simple, globally composable, temporally
> trackable, and implementation-agnostic. This is the working assumption for the
> entire skill set, not a hypothesis to be re-litigated each turn. See
> `effortless-cmcc` for the full statement, falsifiability conditions, and receipts.

This skill provides the mental model and routes to sub-skills. It does not contain command sequences — those live in the leaf skills.

## What makes a project "Effortless"

A project is **Effortless** if and only if BOTH are true:

1. `effortless.json` (or legacy `ssotme.json`) exists at the project root.
2. A `CLAUDE.md` at the project root explicitly identifies the project as following the Effortless Rulebook (ERB) methodology.

**This dual marker is the load gate for every effortless-* skill.** None of these skills should activate willy-nilly — they apply only inside projects that have been deliberately marked as Effortless. The individual skill descriptions carry only a one-phrase scope tag; **this section is the canonical load-gate policy** they all defer to.

### Load-gate policy (canonical — every skill defers here)

| Class | Loads when | Skills |
|---|---|---|
| **Project-only** ("ERB projects only") | Both markers present. Never otherwise. | `effortless-conventions`, `effortless-diagnostics`, `effortless-excel-export`, `effortless-loop`, `effortless-meta-table`, `effortless-pipeline`, `effortless-progress-report`, `effortless-query`, `effortless-rulebook-devops`, `effortless-rulebook-editor`, `effortless-schema`, `effortless-security`, `effortless-sql`, `effortless-workflow`, `effortless-xlsx-to-rulebook`, `effortless-ssotme-protocol`, `effortless-explainer-dag` (on demand within a project), `effortless-app` (whenever someone describes the app they want or asks for screens) |
| **Airtable-connected only** | Both markers AND `effortless.json` registers `airtable-to-rulebook`. | `effortless-airtable`, `effortless-airtable-omni` |
| **Entry points** | Both markers, OR the user explicitly asks to set up / install / update Effortless tooling or create a rulebook. Their job is to *create* the marker. | `effortless-orchestrator`, `effortless-init`, `effortless-bootstrap`, `effortless-setup-postgres`, `effortless-setup-sql-server`, `effortless-demo-app`, `effortless-rulespeak`, `effortless-cli`, `effortless-seeds`, `effortless-seed-authoring`, `effortless-claude-updates` |
| **Theory / receipts** | Any evaluative or "why" question about Effortless / ERB / CMCC, regardless of project. | `effortless-cmcc`, `effortless-rationale`, `effortless-rulebooks`, `effortless-ecosystem` |
| **Explicit request only** | Only when the user asks by name/phrase. Never auto-load just because a project uses Postgres, Docker, etc. | `effortless-bases`, `effortless-magic-links`, `effortless-mcp`, `effortless-publish-tool`, `effortless-video` |

If you're in a project that lacks the marker and the user hasn't explicitly invoked Effortless tooling, do **not** load these skills. If the user wants to convert an existing project into an Effortless project, route to **effortless-init**.

## The ERB Mental Model

```
   INPUT SPOKES (write to the hub)              OUTPUT SPOKES (regenerated from hub)
   ┌──────────────────────────────┐             ┌──────────────────────────────────┐
   │ LLM-direct edits  (default)  │             │ Postgres (vw_* views + tables)   │
   │ Hand-edits (with permission) │             │ Go / Python / TS / OWL / XLSX    │
   │ Airtable / Excel (optional)  │             │ Docs / diagrams / explain-DAG    │
   │ Reverse-sync from Postgres   │             │ ... 11+ substrates today         │
   └──────────────┬───────────────┘             └──────────────▲───────────────────┘
                  │                                            │
                  └───────────────▶  effortless-rulebook.json  ┘
                                    (THE HUB — single source of truth)

   For Postgres spoke specifically:
       views.vw_*  <-- ALWAYS READ FROM THESE
       tables.*    <-- ALWAYS WRITE TO THESE
```

The privileged combination today is **LLM + ERB + Postgres**: an LLM tends the
rulebook JSON directly (or via Airtable when convenient), and `effortless build`
projects it into an ACID-compliant Postgres substrate. Airtable is great as a
human-friendly editing surface but is no longer the SSoT — the JSON file is.

## My Posture

Inside an ERB project, the transpilers are the code authors. I'm a **rulebook
tender** — the places where my work persists are:

1. The **hub** (`effortless-rulebook.json` directly, or via any connected input spoke — Airtable, reverse-sync, hand-edits with permission).
2. The **customization seams** — `ERBCustomizations` rows in the rulebook (preferred) and the hand-edited `*b-customize-*` files — and the **application layer** that consumes the generated views.

Everything else — generated `00`-`05` SQL, generated Python/Go/docs — is
mechanical output. It's fine to read or even edit those files to test a
hypothesis, but the next `effortless build` rewrites them, so edits there
don't persist. When a generated artifact looks wrong, the high-leverage move
is to trace back to the rulebook entry that produced it and fix it there;
patching the artifact directly is at best temporary.

When a request feels like "write some imperative business logic," the first
move is to ask whether it's actually a Lookup, Aggregation, or Formula in
disguise (usually: yes — see `effortless-cmcc`). If that genuinely doesn't fit,
a customization seam is the right escape hatch — with a short comment
explaining why the rulebook can't express the rule.

Staying on the declarative side of the line isn't stylistic preference; it's
what keeps the substrate-equivalence guarantee intact across every target.

## Evaluative Posture (when asked to assess the methodology itself)

Operational posture above is for *doing work* inside ERB. This section is for *judging* ERB — and the rule is different.

The shorthand: **the user is asking me to think *with* the methodology, not *about* it from the outside.** If they want outside-view, they'll say so.

## ORCHESTRATION RULE — `effortless-rulebook.json` LIVES IN `/effortless-rulebook/`

**Always** at `/effortless-rulebook/effortless-rulebook.json`. NEVER at the project root. This applies to every project — Rulebook-First (the default) and Airtable-connected alike.

Before installing or running ANY transpiler that writes to `effortless-rulebook.json` — `raw-text-to-rulebook`, hand-authoring the file, or (only if the project is Airtable-connected) `effortless airtable-to-rulebook` / `effortless -install airtable-to-rulebook` — you MUST `cd effortless-rulebook` first. Running from the root dumps the rulebook in the wrong place AND poisons every subsequent build.

If `effortless-rulebook.json` ever appears at the project root: bug — delete it, fix `effortless.json` so the relevant transpiler has `RelativePath: /effortless-rulebook`, redo the install from inside `/effortless-rulebook/`.

## Critical Guardrails

These are the defaults this skill suite enforces. The developer can override
any of them, but Claude defaults to the safe path unless told otherwise. The
reasoning is mechanical, not moral — but the guardrails are non-negotiable
without explicit override:

1. **Query the rulebook FIRST — NEVER read generated files.** The hub is the
   only place a change persists across builds. Generated files (`00`-`05` in
   `postgres/`, plus other output spokes) are rewritten on every
   `effortless build`. Root nodes in the rulebook are entity names with
   `schema` and `data` sub-properties. Query for tables first, then fields
   from just those tables — never read the full file (can be MB). NEVER cat
   generated SQL (00-05) into context. If you need to know view columns, run
   `psql -c "\d vw_tablename"`.
2. **NEVER edit generated files.** Files `00`-`05` in `postgres/` are
   overwritten on every build. `00b`-`05b` are the customization seams —
   appropriate for infrastructure the hub doesn't model (auth tenants, JWT
   helpers, role GRANTs). For business entities, the hub is usually a better
   fit.
3. **Always read from `vw_*` views; always write to base tables directly.**
   Views include calculated/lookup/aggregation fields; base tables only have
   raw columns, and the views aren't updatable anyway. **And name the
   columns you read** — in SQL and over the API (`?fields=A,B,C`): every
   view column is a function call that Postgres evaluates only when named,
   so `SELECT *` (or a bare `GET /api/tables/<T>`) runs every rule on the
   table for every row. Whole rows belong only on a record page that shows
   the whole row. (`effortless-sql`, `effortless-rulebook-editor`.)
4. **Always ask permission** before modifying the rulebook JSON directly.
   It's the SSoT — the developer should be choosing when it changes.
5. **`effortless build` is usually the final step**, except when
   reverse-syncing rulebook → Airtable (build would overwrite HEAD JSON
   before the push completes).
6. **NEVER write SQL migrations on local-dev projects.** Local Postgres is
   regenerated from scratch by `init-db.sh` on every build — there is no
   `migrations/` folder, no migrations tracking table, no incremental
   deltas. Schema changes go through the rulebook (edit the JSON, or edit
   via Airtable if connected) → `effortless build`. If the answer feels
   like "write a migration / `ALTER TABLE` / insert into a migrations log,"
   the answer is **"edit the rulebook and rerun `effortless build`."** The
   lone exception is `bases.effortlessapi.com`-hosted databases, which use
   `postgres/apply-migration.sh` because the DB can't be dropped — see
   `effortless-bases`. Even there, schema still originates in the rulebook.
   Full statement in `effortless-workflow` "NO MIGRATIONS" section.

## Token Discipline (CANONICAL — leaf skills reference this)

This is the canonical statement for the entire ERB skill suite.

**`effortless build` is a zero-context operation.** Deterministic regeneration; you don't need to read the output. The pattern is:

```
Determine something changed → `effortless build` → commit → DONE
```

Do NOT:
- Read generated files after a build to "verify" them
- Cat SQL files into context
- **Read `effortless-rulebook.json` directly** — the file is the hub and can be megabytes. A direct `Read` or `cat` floods context and defeats the entire point of having a structured rulebook. This is one of the biggest benefits of ERB: you never have to read the whole thing.
- **Use the `query_rulebook` MCP tool** — it adds a network round-trip and is no better than a local one-liner. It is never the right first move for querying schema.
- For planning purposes specifically, the minimized schema alone is almost always sufficient — see `effortless-query`.

You already knew the schema before the build because you queried it. Trust the pipeline.

**Context-window rule:** Use `effortless-query` python one-liners that extract only the table/field metadata you need. A 5-line one-liner is worth 1000× reading the whole file.

**Derived rulebooks (`minimize-rulebook`):** if this transpiler is registered in
`ProjectTranspilers`, climb the derived files in order — `*.derived-read-me-1st.txt`
(table/field names, read first, always) → `*.derived-schema.min.json` →
`*.derived-schema.json` → full rulebook → `*.derived-data.json` (data rows, on
demand only — never the default first read). These exist specifically so you
never have to read the full rulebook to query it. If the project doesn't have this
transpiler yet, ask the user whether to install it — see `effortless-query` for
the full discipline and `effortless-workflow` for writing via code instead of
tokens.

### Why `minimize-rulebook` matters beyond token savings

`minimize-rulebook` isn't just a compact-read convenience — it's the mechanism
that lets the whole skill suite (and the agents working inside it) stay small
and stay isolated.

**The SSoT isn't in the code, so the agent doesn't have to keep reversing it.**
In a hand-written codebase, an LLM re-derives "how does this system work" by
reading source across many files, over and over, every session, because the
model of the system only exists implicitly in the code. In ERB, the model
*is* the rulebook — explicit, declarative, and small relative to the code it
generates. Once `minimize-rulebook` has run, that model is also sitting
right next to the hub in an already-digested form. An agent (or a fresh
sub-agent with zero prior context) can answer "what tables exist," "what
does this field depend on," or "what's the FK shape here" by reading a
~30-line `read-me-1st.txt`, without opening a single generated file and
without having been present for any prior conversation about the project.

**This is what makes sub-agent fan-out safe for ERB work.** Most steps in an
ERB pipeline are deterministic and isolated from each other — editing one
table's formula doesn't require understanding the whole app's runtime
behavior, because the DAG is explicit in the schema, not implicit in
call-graphs. That means many tasks (schema questions, formula audits,
per-table documentation, diagnostics) can be delegated to a sub-agent that
starts cold, reads only the derived ladder for the slice it needs, and
answers — instead of requiring the full conversational context or a
from-scratch codebase crawl. This does not extend to the application/UI
layer, which still has to be understood by actually reading the frontend
code — but even there, the *data model* half of that understanding comes
free by reading `schema.min.json` instead of reverse-engineering it from
queries scattered across the app.

**Net effect on the skill suite's shape:** the more a project leans on
`minimize-rulebook`, the less any individual skill needs to embed deep
structural knowledge inline, because that knowledge is discoverable at
query-time from the derived files rather than needing to be pre-loaded from
a skill doc. `effortless-schema` in particular exists mainly for the *first*
time an agent (or project) needs the full structural explanation; after
`minimize-rulebook` is installed, most day-to-day schema questions are
answered by the ladder itself, not by re-reading that skill.

**Install it early.** Because so much of the rest of the suite's token
discipline depends on the derived ladder existing, `minimize-rulebook`
should be among the first transpilers registered on any new ERB project —
see `effortless-pipeline` for where it sits in `ProjectTranspilers` order.

### Quick query patterns (full library in `effortless-query`)

```bash
# List all tables + field/row counts
cat effortless-rulebook/effortless-rulebook.json | python3 -c "
import sys,json; d=json.load(sys.stdin)
skip={'\$schema','Name','Description','_meta'}
for k in d:
  if k not in skip and isinstance(d[k],dict) and 'schema' in d[k]:
    print(f'  {k}: {len(d[k][\"schema\"])} fields, {len(d[k].get(\"data\",[]))} rows')
"

# Show schema for one table (replace TableName)
cat effortless-rulebook/effortless-rulebook.json | python3 -c "
import sys,json; d=json.load(sys.stdin)
for f in d['TableName']['schema']:
  print(f'  {f[\"name\"]:30s} {f[\"type\"]:15s} {f[\"datatype\"]:10s} {f.get(\"Description\",\"\")[:60]}')
"
```

## Schema Change Decision Tree

**Default (Rulebook-First):** edit `effortless-rulebook.json` directly (with
permission), then `effortless build`. This is the best-practice path and the only
one available unless the project explicitly opted into an upstream surface.

**If the project is Airtable-connected** (check `effortless.json` for an
`airtable-to-rulebook` transpiler), the Airtable path is *also* available as a
sibling option — useful when a human prefers the grid. It's never required.

```
NEW BUSINESS ENTITY (users, roles, products, orders, profiles)?
  Rulebook-First (default) → edit effortless-rulebook.json, add the table object.
  Airtable-connected, optional → new table via OMNI (needs Name formula).
  Then `effortless build`.

Scalar field (text, number, select, checkbox, date, FK link)?
  Rulebook-First (default) → edit the JSON directly
  Airtable-connected, optional → Airtable REST API (effortless-airtable)

Formula, lookup, or rollup?
  Rulebook-First (default) → edit the JSON directly (LLMs are excellent at this —
                             the rulebook is JSON, formulas/lookups/rollups are
                             just fields)
  Airtable-connected, optional → OMNI via Playwright (effortless-airtable-omni)
                             node "$OMNI" <baseId> '<prompt>'  ($OMNI: see effortless-airtable-omni → Usage)

CRUD on records?
  Rulebook-First (default) → write to Postgres tables; reverse-sync if you need
                             the rulebook to capture seed data
  Airtable-connected, optional → Airtable REST API
```

**If using OMNI: never generate OMNI prompts for the user to paste.** Drive OMNI directly via `omni-send.mjs`.

## When You Need More Detail

Sub-skills load automatically based on what you're doing:

| Skill | When to Use |
|---|---|
| `effortless-cli` | CLI commands AND install/update of the `effortless` binary itself |
| `effortless-seeds` | Starting a project from a seed, or dropping an add-in seed (magic links, Shopify, backend) into one: `listSeeds`/`cloneSeed`, seed sources, `$key$` replacements |
| `effortless-seed-authoring` | Building, testing and publishing seeds: the add-in shape, manifest, rulebook fragments, the gotchas already found |
| `effortless-init` | Initializing a new effortless project (project structure, CLAUDE.md, start.sh, Airtable connection) |
| `effortless-setup-postgres` | First-run setup for Postgres-targeted projects (preflight + init-db + everything in -init) |
| `effortless-setup-sql-server` | Same first-run setup with SQL Server as the substrate (`rulebook-to-sql-server`, sqlcmd, mssql) |
| `effortless-bootstrap` | Bootstrapping from raw text — Shadle steps from vocabulary to rulebook |
| `effortless-ssotme-protocol` | Exact `effortless.json` schema — load before emitting any `ProjectTranspilers` entry |
| `effortless-meta-table` | The `__meta__` global name/value settings table (transpiler-ignored) |
| `effortless-progress-report` | Delivery / status / priced-plan reports derived from the rulebook; adds the delivery spine tables |
| `effortless-rulebook-devops` | Dev/staging/beta/production promotion model, migration ledger, Deployment Management console (heavy, once per project) |
| `effortless-mcp` | The Effortless MCP server — wiring any MCP client to the transpiler catalog |
| `effortless-publish-tool` | Publishing a new version of a transpiler tool from `Versioned-Stable-SSoTme-Tools` |
| `effortless-video` | Explainer videos in the `effortless-vid-01-full-name` producer repo |
| `effortless-loop` | The iterative dev cycle — "the loop", "do a turn", "rebuild the rulebook" |
| `effortless-query` | Querying the rulebook JSON — listing tables, extracting schema, finding relationships |
| `effortless-schema` | Understanding the JSON structure — field types, datatypes, formula syntax, `_meta` |
| `effortless-conventions` | Naming, DAG, PK/FK rules, no many-to-many |
| `effortless-xlsx-to-rulebook` | Porting an Excel/Sheets spreadsheet into a rulebook — the syntax gaps (1-hop-only being the big one) |
| `effortless-workflow` | Editing the hub — directly, via Airtable, or via reverse-sync; permission checkpoints |
| `effortless-pipeline` | `effortless.json`, transpilers, build mechanics |
| `effortless-sql` | Generated SQL — views vs tables, `00`-`05` files, `*b-customize-*` |
| `effortless-security` | Roles and who sees what — the `<Role>CRUD` matrix, `role_<id>` schemas, per-role `.d.ts` types, hiding columns to make a persona fast |
| `effortless-airtable` | *(only if Airtable-connected)* Airtable REST API — scalar fields, CRUD |
| `effortless-airtable-omni` | *(only if Airtable-connected)* OMNI via Playwright — formulas, lookups, rollups, new tables |
| `effortless-diagnostics` | Diagnostic queries, DAG validation, legacy code migration |
| `effortless-bases` | bases.effortlessapi.com + magic-links + RLS in 5 minutes |
| `effortless-magic-links` | Magic-link auth on ANY Postgres-backed project |
| `effortless-excel-export` | Adding Excel export from live Postgres data |
| `effortless-rulebook-editor` | **Recommended default on rulebook creation** — instant DB + API + admin UI + plain-English rule docs from a bare rulebook, zero app code. Not required, but the fastest way to have something real to look at |
| `effortless-rulespeak` | No-Docker alternative to `effortless-rulebook-editor` — `rulebook-to-rulespeak` → static `rulespeak/rulespeak.html` + `.md` |
| `effortless-explainer-dag` | **Explainer DAG (on demand)** — in-app `rulebook-to-explainer-dag`, `data-er-dag`, hover + full field pages. Load only when user asks; not default for POCs |
| `effortless-app` | **Building the app people use** on a rulebook: personas, user stories per persona, routes, then a phone-first app with provenance and a persona picker |
| `effortless-demo-app` | Spin up a complete demo POC from a one-line domain description |
| `effortless-claude-updates` | Anything about the **skill set** — check, update, author skills |
| `effortless-cmcc` | The conceptual floor — SDLAF, bitemporal ACID DAG, the 5 primitives |
| `effortless-rulebooks` | Empirical demonstration — substrates, ExplainDAG, conformance |
| `effortless-ecosystem` | Catalog of public repos in SSoTme / effortlessapi orgs |
| `effortless-rationale` | Skeptic-facing answers grounded in receipts |

## Quick Reference

- **Tables**: PascalCase, plural (`Customers`, `WorkflowSteps`)
- **`Name` is ALWAYS the first field** — formula compound key, the logical primary key
- **No `{Entity}Id` fields** — surrogate keys live in the substrate, off-screen
- **Foreign keys**: singular entity name, no "Id" suffix (`Order.Customer`)
- **Reverse FKs**: plural (`Customer.Orders`)
- **It's a DAG**: 1-to-many only; no cycles, no many-to-many
- **Every field** has a `Description`
- **Schema is small, data is big** — query for entities, never read whole file
- **Default change path**: Rulebook-First (edit the hub → build). Airtable/Excel are optional sibling input spokes if the project opted in.
- **Recommended default on new rulebooks**: install `effortless-rulebook-editor` → instant DB + API + admin UI + rule docs (not required — see `effortless-rulebook-editor`; no-Docker alternative is `effortless-rulespeak`)
- **`effortless build`** runs enabled transpilers; `-id` includes disabled ones
- **`effortless.json`** defines the build pipeline

## See also

- `effortless-init` — for the actual init walkthrough referenced above.
- `effortless-claude-updates` — for "update effortless skills" / authoring new skills.
- `effortless-loop` — for the iterative dev cycle.
- `effortless-query` — for the targeted JSON queries the Token Discipline section requires.
- `effortless-conventions` — full naming/DAG rules.

---

## Magic-links refactor (v0.2)

> See [../../MAGIC_LINKS_REFACTOR.md](../../MAGIC_LINKS_REFACTOR.md) §7 for the canonical v0.2 magic-links contract.

Routing for magic-links work:
- Anything touching `bases.effortlessapi.com` → route to `effortless-bases` (read its hard-gate block first).
- Auth / RLS / tenant / `auth.trusted_tenants` / `app.jwt_email` / JWT-verify → `effortless-magic-links`.
- Postgres bootstrap (init-db.sh / install / `effortless build` / schema changes) → `effortless-setup-postgres` AND ensure §1's canonical install step is part of the bootstrap.
